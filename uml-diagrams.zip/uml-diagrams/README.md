# ShopTrack – UML diagrams (PlantUML)

Every diagram in Section 5 of the report is written as PlantUML text and rendered to PNG.

| File | Diagram |
|---|---|
| 01_usecase.puml | Use case diagram (11 use cases, «include», «extend», actor generalisation) |
| 02_class.puml | Class diagram (14 classes/interfaces, multiplicity, role names, composition, aggregation, generalisation) |
| 03_object.puml | Object diagram (snapshot just before checkout) |
| 04_seq_add_item.puml | Sequence diagram 1 – add item to bill |
| 05_seq_checkout.puml | Sequence diagram 2 – finalize and save bill |
| 06_activity.puml | Activity diagram – billing workflow |
| 07_state_stock.puml | State chart – product stock status |
| 08_state_bill.puml | State chart – bill lifecycle |
| 09_component_deployment.puml | Component and deployment diagram |
| common.iuml | Shared colours and fonts, included by every diagram |

## How to render

**Option 1 – online:** paste the contents of a `.puml` file into https://www.plantuml.com/plantuml
(replace the line `!include common.iuml` with the contents of `common.iuml`, or just delete that line).

**Option 2 – VS Code:** install the "PlantUML" extension (jebbs), open a `.puml` file and press Alt+D to preview, or right-click → Export.

**Option 3 – command line** (needs Java and Graphviz):

```
java -jar plantuml.jar -tpng -charset UTF-8 *.puml
```

PNG files are written next to the `.puml` files. Rendered copies are already in `images/`.
